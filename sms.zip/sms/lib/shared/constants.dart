import 'package:flutter/material.dart';

const Color kXiketic = Color(0xFF0A0E21);
const Color kAmaranth = Color(0xFFEB1555);
const Color kMediumAquamarine = Color(0xFF14EBAA);
const Color kRussianViolet = Color(0xFF0C0A3E);
const Color kOxfordBlue = Color(0xFF111328);
const Color kSpaceCadet = Color(0xFF1D1E33);
const Color kRichBlackFOGRA29 = Color(0xFF161B22);
const Color kTurquoise = Color(0xFF03DAC5);
